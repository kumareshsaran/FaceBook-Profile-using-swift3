//
//  ViewController.swift
//  ProfilePhoto
//
//  Created by Apple on 11/03/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit
import FBSDKLoginKit

class ViewController: UIViewController,FBSDKLoginButtonDelegate {
  
    @IBOutlet weak var WelComeLable: UILabel!
    @IBOutlet weak var Image: UIImageView!
    
       @IBOutlet weak var FIrstName: UILabel!
   
    override func viewDidLoad() {
        super.viewDidLoad()
    
        var userprofile = FBSDKProfilePictureView()
        
        print("hi\(userprofile)")
        //let profile=UIImage
       // let username = FBSDKpro
        let loginButton = FBSDKLoginButton()
        loginButton.readPermissions=["email","public_profile"]
        view.addSubview(loginButton)
        view.addSubview(userprofile)
        //view.addSubview(username)
    
        //userprofile = Image
        //frame's are obselete, please use constraints instead because its 2016 after all
        //username.frame
        userprofile.frame = CGRect(x: 20, y:30 , width:100, height: 100)
        
       // userprofile.layer.cornerRadius = userprofile.frame.size.width/2
       // userprofile.clipsToBounds = nilR
        userprofile.layer.cornerRadius = userprofile.frame.size.width / 2;
        userprofile.clipsToBounds = true
        
        //userprofile.clipsToBounds
        
        userprofile.contentMode = .scaleAspectFill
        userprofile.layer.cornerRadius = 50
        userprofile.layer.masksToBounds = true
        self.WelComeLable.isHidden=true
        
        
        loginButton.frame = CGRect(x: 16, y: 200, width: view.frame.width - 32, height: 100)
        
        loginButton.delegate = self
        
        
        
        
        if let token = FBSDKAccessToken.current(){
            fetchprofile()
        }
    }
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        
        
        self.WelComeLable.isHidden=false
        
        if error != nil {
            print(error)
            return
        }
        
        print("Successfully logged in with facebook...")
 
        fetchprofile()
    }
    
    func fetchprofile(){
        print("fetch profile")
      
        
        let  parameter=["filed" : "email , first_name , last_name, picture.type[large]"]
        FBSDKGraphRequest(graphPath: "/me",parameters:parameter).start(completionHandler: { (connection, result, error)-> Void in
            var name = " "
            print(error)
            print(result)
           // if error != nil {
            if let username = result as? NSDictionary{
                 name = (username["name"] as? String)!
                print(name)
                self.FIrstName.text = name
            }else{
                
                print("name \(name)")
                //name=name.replacingOccurrences(of: "\"", with: "")
                print("helo \(name)")
                self.FIrstName.text = name
            }
               /* if let userDict = result as! NSDictionary{
                    let first_name = userDict["first_name"] as! String
                    //let first_name = ["first_name"] as? String
                    print("hi \(first_name)")
                    self.username.text = "hi \(first_name)"
                    //self.show(true, sender:first_name)
                    print(first_name)
                }
                if error != nil{
                    print(error)
                    return
                }
                
           // }*/
            
            
             //if let email = result["email"] as? String{
           // print(email)
            // }
             
             //if let picture = result["picture"] as? NSDictionary,let data=picture["data"] as? NSDictionary,let url = data["url"] as? String{
             //print(url)
            // }*/
            
        });
        

        
        
           }
    
    func loginButtonDidLogOut(_ _loginButton: FBSDKLoginButton!) {
        print("Did log out of facebook")
        self.WelComeLable.isHidden=true
        self.FIrstName.isHidden=true
        
        
    }
        
        
        func loginButtonWillLogin(loginButton:FBSDKLoginButton)->Bool{
              self.WelComeLable.isHidden=true
            return true
        }
    
    }


